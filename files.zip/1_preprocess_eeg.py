import numpy as np
from scipy.signal import butter, lfilter, iirnotch
from sklearn.preprocessing import StandardScaler
from mne.preprocessing import ICA

def butter_bandpass(lowcut, highcut, fs, order=5):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return b, a

def apply_bandpass(data, lowcut=0.1, highcut=100, fs=256, order=4):
    b, a = butter_bandpass(lowcut, highcut, fs, order=order)
    return lfilter(b, a, data)

def apply_notch(data, notch_freq=50, fs=256, Q=30):
    b, a = iirnotch(notch_freq, Q, fs)
    return lfilter(b, a, data)

def run_ica(data, fs):
    # داده باید به شکل (n_channels, n_samples)
    ica = ICA(n_components=data.shape[0], random_state=97, max_iter=800)
    # فرض: data در ابعاد (channels, samples)
    ica.fit(data)
    return ica.apply(data)

def preprocess_subject(raw, fs, do_ica=False):
    # raw: (channels, samples)
    for ch in range(raw.shape[0]):
        raw[ch] = apply_bandpass(raw[ch], 0.1, 100, fs)
        raw[ch] = apply_notch(raw[ch], 50, fs)
    if do_ica:
        raw = run_ica(raw, fs)
    return raw

def extract_windows(data, label, selected_channels, fs=256, win_len_sec=4, overlap=0.75):
    windows = []
    labels = []
    window_size = int(win_len_sec * fs)
    step = int(window_size * (1 - overlap))
    n_wins = (data.shape[1] - window_size) // step + 1
    for w in range(n_wins):
        seg = data[selected_channels, w*step:w*step+window_size]
        seg = StandardScaler().fit_transform(seg.T).T  # Z-score روی هر کانال
        windows.append(seg[..., np.newaxis])  # (channels, window_size, 1)
        labels.append(label)
    return windows, labels

# ---------- MAIN PIPELINE ----------
# فرض: eeg_data: (n_subject, n_channels, n_samples), labels: (n_subject,)
# selected_channels: اندیس‌های 19 کانال استاندارد در دیتاست شما
eeg_data = np.load('eeg_data_raw.npy')    # باید داده خام خود را اینجا قرار دهید
labels = np.load('labels_raw.npy')
selected_channels = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18]  # ویرایش طبق دیتاست MODMA

all_windows = []
all_labels = []
fs = 256
for subj in range(eeg_data.shape[0]):
    print(f"Preprocessing subject {subj+1}/{eeg_data.shape[0]}")
    d = preprocess_subject(eeg_data[subj], fs, do_ica=False)
    wins, labs = extract_windows(d, labels[subj], selected_channels, fs)
    all_windows.extend(wins)
    all_labels.extend(labs)

X = np.stack(all_windows)
y = np.array(all_labels)
np.save('X_modma_deprnet.npy', X)
np.save('y_modma_deprnet.npy', y)
print(f"Done! Saved: X_modma_deprnet.npy, y_modma_deprnet.npy")