import numpy as np
import tensorflow as tf
from deprnet_model import build_deprnet
from sklearn.model_selection import KFold
from sklearn.metrics import classification_report, roc_auc_score
from tensorflow.keras.callbacks import EarlyStopping

X = np.load('X_modma_deprnet.npy')
y = np.load('y_modma_deprnet.npy')
y_cat = tf.keras.utils.to_categorical(y, num_classes=2)

kf = KFold(n_splits=10, shuffle=True, random_state=42)
metrics_list = []
fold = 1
for train_index, test_index in kf.split(X, y_cat):
    print(f"Fold {fold}...")
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y_cat[train_index], y_cat[test_index]
    # 80% train, 20% val
    val_split = int(0.8 * len(X_train))
    indices = np.arange(len(X_train))
    np.random.shuffle(indices)
    train_idx, val_idx = indices[:val_split], indices[val_split:]
    X_tr, X_val = X_train[train_idx], X_train[val_idx]
    y_tr, y_val = y_train[train_idx], y_train[val_idx]
    model = build_deprnet()
    model.compile(
        optimizer=tf.keras.optimizers.Adam(
            learning_rate=0.0005, beta_1=0.9, beta_2=0.999, epsilon=1e-7),
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    early = EarlyStopping(monitor='val_loss', patience=7, restore_best_weights=True)
    model.fit(X_tr, y_tr, epochs=25, batch_size=64,
              validation_data=(X_val, y_val), callbacks=[early], verbose=2)
    y_pred = model.predict(X_test)
    y_test_labels = np.argmax(y_test, axis=1)
    y_pred_labels = np.argmax(y_pred, axis=1)
    report = classification_report(y_test_labels, y_pred_labels, output_dict=True)
    auc = roc_auc_score(y_test, y_pred)
    print(f"Fold {fold}: Accuracy={report['accuracy']:.4f}, AUC={auc:.4f}")
    metrics_list.append({'accuracy': report['accuracy'], 'auc': auc})
    fold += 1
print("CV Results:")
print("Mean accuracy:", np.mean([m['accuracy'] for m in metrics_list]))
print("Mean AUC:", np.mean([m['auc'] for m in metrics_list]))