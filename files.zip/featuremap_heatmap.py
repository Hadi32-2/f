import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from deprnet_model import build_deprnet
import tensorflow as tf

# بارگذاری داده و مدل آموزش دیده
X = np.load('X_modma_deprnet.npy')
y = np.load('y_modma_deprnet.npy')
y_cat = tf.keras.utils.to_categorical(y, num_classes=2)
model = build_deprnet()
model.load_weights('best_deprnet_weights.h5')  # فرض بر اینکه مدل ذخیره شده

# استخراج خروجی لایه maxpooling پنجم (M5)
layer_name = [l.name for l in model.layers if 'max_pooling1d_4' in l.name][0]
intermediate_layer_model = tf.keras.Model(inputs=model.input,
                                outputs=model.get_layer(layer_name).output)
m5_activations = intermediate_layer_model.predict(X)  # (samples, time, filters)

# میانگین‌گیری طبق مقاله: اول روی فیلترها و زمان، سپس روی windowهای هر سابجکت
subject_indices = ...  # آرایه اندیس شروع و پایان windowهای هر سابجکت
response_vectors = []
for i, (start, end) in enumerate(subject_indices):
    subject_act = m5_activations[start:end]  # همه windowهای یک سابجکت
    mean_act = np.mean(subject_act, axis=(0,1))  # میانگین روی samples و time
    response_vectors.append(mean_act)  # طول=19 کانال

# رسم heatmap برای سابجکت افسرده و سالم
for idx in [np.where(y==0)[0][0], np.where(y==1)[0][0]]:
    plt.figure()
    sns.heatmap(response_vectors[idx].reshape(1,-1), cmap='coolwarm', cbar=True, xticklabels=False, yticklabels=False)
    plt.title(f"Subject {idx}, Label: {'Depressed' if y[idx]==1 else 'Healthy'}")
    plt.show()